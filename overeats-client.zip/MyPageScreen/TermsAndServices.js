import React, { Fragment } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Image,
  Alert,
  AsyncStorage,
  Button
} from 'react-native';
import { createStackNavigator } from 'react-navigation';
import terms from './termsAndServiceTxT';
import privacyTerms from './PrivacyTxT';

class TermsAndServices extends React.Component {
  state = {
    clickedAgreementsAtOnce: false,
    clickedBaeminTerms: false,
    clickedPaymentTerms: false,
    clickedPrivacyTerms: false,
    clickedMarketingTerms: false,
    modalVisibleForBaeminAndPaymentTerms: false,
    modalVisibleForPrivacy: false
  };

  handleCheckbox = whichOne => {
    if (whichOne === 'clickedBaeminTerms') {
      this.setState({ clickedBaeminTerms: !this.state.clickedBaeminTerms });
    } else if (whichOne === 'clickedPaymentTerms') {
      this.setState({ clickedPaymentTerms: !this.state.clickedPaymentTerms });
    } else if (whichOne === 'clickedPrivacyTerms') {
      this.setState({ clickedPrivacyTerms: !this.state.clickedPrivacyTerms });
    } else if (whichOne === 'clickedMarketingTerms') {
      this.setState({
        clickedMarketingTerms: !this.state.clickedMarketingTerms
      });
      if (this.state.clickedMarketingTerms) {
        AsyncStorage.setItem('marketingAgreement', JSON.stringify(true));
      }
    }
  };

  handleAllAgreements = () => {
    if (!this.state.clickedAgreementsAtOnce) {
      this.setState({
        clickedAgreementsAtOnce: true,
        clickedBaeminTerms: true,
        clickedPaymentTerms: true,
        clickedPrivacyTerms: true,
        clickedMarketingTerms: true
      });
    } else {
      this.setState({
        clickedAgreementsAtOnce: false,
        clickedBaeminTerms: false,
        clickedPaymentTerms: false,
        clickedPrivacyTerms: false,
        clickedMarketingTerms: false
      });
    }
  };

  openModalForBaeminAndPaymentTerms = () => {
    this.setState({ modalVisibleForBaeminAndPaymentTerms: true });
  };

  openModalForPrivacy = () => {
    this.setState({ modalVisibleForPrivacy: true });
  };

  closeModalForBaeminAndPaymentTerms = () => {
    this.setState({
      modalVisibleForBaeminAndPaymentTerms: false,
      clickedBaeminTerms: true,
      clickedPaymentTerms: true
    });
  };

  closeModalForPrivacy = () => {
    this.setState({ modalVisibleForPrivacy: false, clickedPrivacyTerms: true });
  };

  checkAgreementsStatus = () => {
    return (
      this.state.clickedBaeminTerms &&
      this.state.clickedPaymentTerms &&
      this.state.clickedPrivacyTerms
    );
  };

  render() {
    return (
      <View style={styles.termsbackground}>
        {/* 배달의민족 이용약관/전자금융거래 이용약관 모달 */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVisibleForBaeminAndPaymentTerms}
          onRequestClose={this.closeModalForBaeminAndPaymentTerms}
        >
          <View style={styles.modalContainer}>
            <ScrollView>
              <Text style={styles.description}>{terms}</Text>
            </ScrollView>
            <Button
              color="#51cdca"
              onPress={this.closeModalForBaeminAndPaymentTerms}
              title=" 동의하고 닫기 "
            />
          </View>
        </Modal>
        {/* 개인정보수집이용동의 약관 모달 */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVisibleForPrivacy}
          onRequestClose={this.closeModalForPrivacy}
        >
          <View style={styles.modalContainer}>
            <ScrollView>
              <Text style={styles.description}>{privacyTerms}</Text>
            </ScrollView>
            <Button
              color="#51cdca"
              onPress={this.closeModalForPrivacy}
              title=" 동의하고 닫기 "
            />
          </View>
        </Modal>
        {/* 좌측 상단 종료 버튼(X) */}
        <TouchableOpacity
          style={styles.topArea}
          onPress={() => this.props.navigation.navigate('MyPageScreen')}
        >
          <Image source={require('../imgs/icons/x.png')} style={styles.x} />
        </TouchableOpacity>
        {/* '우와' 이미지 */}
        <ScrollView>
          <View>
            <Image
              source={require('../imgs/signup/wow.png')}
              style={styles.wowImg}
            />
          </View>
          {/* 약관동의체크 */}
          <View>
            <View style={styles.flexDirectionColumn}>
              <Text style={styles.needAgreementsText}>어서오세요</Text>
              <View style={styles.rowSpaceBetween}>
                <Text style={styles.needAgreementsText}>
                  약관동의가 필요해요
                </Text>
                <View style={styles.rowFlexEndMargin30}>
                  <Text style={styles.allAgreeText}>전체동의</Text>
                  {this.state.clickedAgreementsAtOnce ? (
                    <TouchableOpacity onPress={this.handleAllAgreements}>
                      <Image
                        source={require('../imgs/signup/checked.png')}
                        style={styles.bigCheckboxImg}
                      />
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity onPress={this.handleAllAgreements}>
                      <Image
                        source={require('../imgs/signup/unchecked.png')}
                        style={styles.bigCheckboxImg}
                      />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
            <Text style={styles.marginTop20} />
            <View style={styles.flexDirectionColumn}>
              <View style={styles.rowSpaceBetween}>
                <Text
                  style={styles.smallAgreementText}
                  onPress={this.openModalForBaeminAndPaymentTerms}
                >
                  배달의민족 이용약관 동의
                </Text>
                {this.state.clickedBaeminTerms ? (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedBaeminTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/checked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedBaeminTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/unchecked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                )}
              </View>
              <View style={styles.rowSpaceBetween}>
                <Text
                  style={styles.smallAgreementText}
                  onPress={this.openModalForBaeminAndPaymentTerms}
                >
                  전자금융거래 이용약관 동의
                </Text>
                {this.state.clickedPaymentTerms ? (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedPaymentTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/checked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedPaymentTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/unchecked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                )}
              </View>
              <View style={styles.rowSpaceBetween}>
                <Text
                  style={styles.smallAgreementText}
                  onPress={this.openModalForPrivacy}
                >
                  개인정보 수집이용 동의
                </Text>
                {this.state.clickedPrivacyTerms ? (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedPrivacyTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/checked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedPrivacyTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/unchecked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                )}
              </View>
              <View style={styles.rowSpaceBetween}>
                <Text style={styles.smallAgreementTextWithoutUnderline}>
                  마케팅 정보 메일, SMS 수신동의 (선택)
                </Text>
                {this.state.clickedMarketingTerms ? (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedMarketingTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/checked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => this.handleCheckbox('clickedMarketingTerms')}
                  >
                    <Image
                      source={require('../imgs/signup/unchecked.png')}
                      style={styles.smallCheckboxImg}
                    />
                  </TouchableOpacity>
                )}
              </View>
              <Text style={styles.smallAgreementTextWithoutUnderline}>
                만 14세 이상 고객만 가입가능합니다.{'   '}
                <Text
                  style={{ textDecorationLine: 'underline' }}
                  onPress={() =>
                    Alert.alert(
                      '가입제한 안내',
                      '정보통신망 이용촉진 및 정보보호 등에 관한 법률에는 만 14세미만 아동의 개인정보 수집시 법정대리인 동의를 받도록 규정하고 있으며, 만 14세 미만 아동이 법정대리인 동의없이 회원가입을 하는 경우 회원탈퇴 또는 서비스 이용이 제한될 수 있습니다.'
                    )
                  }
                >
                  내용보기
                </Text>
              </Text>
              <Text style={{ color: 'white', fontSize: 10 }}>
                배달의민족은 만 14세 미만 아동의 회원가입을 제한하고 있습니다.
              </Text>
            </View>
            <View>
              <TouchableOpacity
                style={styles.nextStepBtn}
                onPress={() => {
                  const shallGoNext = this.checkAgreementsStatus();
                  if (shallGoNext) {
                    this.props.navigation.navigate('Signup');
                  } else {
                    Alert.alert(
                      '이용약관과 개인정보정책을\n동의해야 회원가입이 가능합니다.'
                    );
                  }
                }}
              >
                <Text style={styles.nextStepText}>다음으로 ></Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  topArea: {
    maxHeight: 50
  },
  x: {
    marginLeft: 10,
    width: 40,
    resizeMode: 'contain'
  },
  termsbackground: {
    flex: 1,
    backgroundColor: '#51CDCA'
  },
  wowImg: {
    marginLeft: 10,
    width: '60%',
    resizeMode: 'contain'
  },
  bigCheckboxImg: {
    width: 30,
    height: 30
  },
  smallCheckboxImg: {
    width: 25,
    height: 25,
    marginTop: 10,
    marginRight: 30
  },
  needAgreementsText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold'
  },
  allAgreeText: {
    width: 80,
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold'
  },
  smallAgreementText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 15,
    marginTop: 20,
    textDecorationLine: 'underline'
  },
  smallAgreementTextWithoutUnderline: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 15,
    marginTop: 20
  },
  flexDirectionColumn: {
    flexDirection: 'column',
    marginLeft: 30
  },
  rowSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  rowFlexEndMargin30: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginRight: 30
  },
  nextStepBtn: {
    backgroundColor: 'white',
    width: 150,
    height: 50,
    marginTop: 20,
    marginRight: 30,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-end',
    borderRadius: 20
  },
  nextStepText: {
    color: '#51CDCA',
    fontWeight: 'bold',
    fontSize: 15
  },
  modalContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: 4,
    borderColor: '#C0C0C0',
    borderRadius: 20,
    borderWidth: 1,
    marginHorizontal: 40,
    marginVertical: 80
  },
  description: {
    color: 'black',
    paddingHorizontal: 20,
    paddingVertical: 20
  },
  marginTop20: { marginTop: 20 }
});

export default createStackNavigator(
  {
    TermsAndServices: { screen: TermsAndServices }
  },
  {
    headerMode: 'none',
    mode: 'modal'
  }
);
