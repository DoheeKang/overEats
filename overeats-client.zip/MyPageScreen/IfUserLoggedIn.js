import React, { Component } from 'react';
import { View, Text, StyleSheet, AsyncStorage, Switch } from 'react-native';
import { sendToken } from '../modules/sendToken';

export default class IfUserLoggedIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      marketingAgree: false,
      userName: '',
      uesrEmail: '',
      userPhoneNumber: ''
    };
  }

  componentDidMount() {
    // this.onLoad();
    this.getUserInfo();
    this.checkMarketingAgreementStatus();
  }

  checkMarketingAgreementStatus = async () => {
    const doesAgreeMarketing = await AsyncStorage.getItem('marketingAgreement');
    if (JSON.parse(doesAgreeMarketing)) {
      this.setState({ marketingAgree: true });
    }
  };

  handleMarketingAgreementStatus = value => {
    this.setState({ marketingAgree: value });
    AsyncStorage.setItem('marketingAgreement', 'true');
  };

  _maskingEmail = str => {
    let findAtIndex = str.indexOf('@');
    let beforeAt = str.substring(0, findAtIndex - 3);
    let remainStrToStars = '';
    for (let i = 0; i < str.substring(findAtIndex).length; i += 1) {
      remainStrToStars += '*';
    }
    return beforeAt + '***@' + remainStrToStars;
  };

  getUserInfo = async () => {
    let isLogin = await AsyncStorage.getItem('isLogin');
    if (JSON.parse(isLogin)) {
      sendToken('/users/info/', {}, null, this.props.navigation)
        .then(result => {
          let { name, email, phoneNumber } = result.data;
          email = this._maskingEmail(email);
          phoneNumber = phoneNumber.slice(-4);
          this.setState({
            userName: name,
            uesrEmail: email,
            userPhoneNumber: phoneNumber
          });
        })
        .catch(err => {
          console.log('sendToken했는데 에러다');
          throw err;
        });
    }
  };

  render() {
    return (
      <View>
        <View style={styles.myInfoContainer}>
          <View style={styles.bottomBorderWidth}>
            <Text style={styles.myInfoTitle}>내 정보</Text>
          </View>
          <Text style={styles.userNameText}>
            고마운 분, {this.state.userName} 님!
          </Text>
          <Text style={styles.userEmailPhoneNumberText}>
            이메일 | {this.state.uesrEmail}
          </Text>
          <Text style={styles.userEmailPhoneNumberText}>
            휴대폰 끝 4자리 | {this.state.userPhoneNumber}
          </Text>
          <View style={styles.marketingSwitchContainer}>
            <Text style={styles.marketingSwitchText}>마케팅 수신동의</Text>
            <Switch
              onValueChange={value =>
                this.handleMarketingAgreementStatus(value)
              }
              value={this.state.marketingAgree}
              thumbColor={'White'}
              trackColor={{ false: 'grey', true: '#51CDCA' }}
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  headerTitle: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  btn: {
    backgroundColor: '#51CDCA',
    marginTop: 10,
    marginLeft: 30,
    marginRight: 30,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center'
  },
  text: {
    color: 'white',
    fontWeight: 'bold',
    margin: 'auto',
    alignItems: 'center'
  },
  myInfoContainer: {
    flexDirection: 'column'
  },
  bottomBorderWidth: {
    borderBottomColor: 'grey',
    borderBottomWidth: 1,
    marginVertical: 10,
    marginHorizontal: 20
  },
  myInfoTitle: {
    fontSize: 25,
    color: 'black',
    fontWeight: 'bold',
    marginVertical: 5
  },
  userNameText: {
    marginHorizontal: 20,
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    marginVertical: 5
  },
  userEmailPhoneNumberText: {
    marginHorizontal: 20,
    color: 'black',
    marginVertical: 5
  },
  marketingSwitchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 5
  },
  marketingSwitchText: {
    marginHorizontal: 20,
    color: 'black',
    marginVertical: 5
  }
});
