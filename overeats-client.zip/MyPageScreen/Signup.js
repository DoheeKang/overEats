import React from 'react';
import {
  View,
  Alert,
  Button,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  StyleSheet
} from 'react-native';
import * as SignupAction from '../modules/SignupAction';
import { inputDash } from '../modules/inputDash';
import { checkValidInfo } from '../modules/checkValidInfoForSignup';

class Signup extends React.Component {
  state = {
    email: '',
    password: '',
    passwordConfirm: '',
    name: '',
    phoneNumber: ''
  };

  joinBtn = () => {
    const { email, password, name, phoneNumber } = this.state;
    const isValid = checkValidInfo({
      email: email,
      password: password,
      name: name,
      phoneNumber: phoneNumber
    });
    if (isValid) {
      SignupAction.signup(
        {
          email: email,
          password: password,
          name: name,
          phoneNumber: phoneNumber
        },
        this.props.navigation
      );
      return;
    } else {
      return Alert.alert('양식에 맞게 입력했는지 다시 한 번 확인해주세요!');
    }
  };

  render() {
    let checkPasswordSame = null;
    if (this.state.password === '') {
      checkPasswordSame = (
        <Text style={styles.passwordUnmatch}>비밀번호를 입력해주세요.</Text>
      );
    } else if (this.state.password === this.state.passwordConfirm) {
      if (this.state.password.length < 8) {
        checkPasswordSame = (
          <Text style={styles.passwordUnmatch}>
            비밀번호는 8자 이상이어야 합니다.
          </Text>
        );
      } else {
        checkPasswordSame = (
          <Text style={styles.passwordMatch}>일치합니다.</Text>
        );
      }
    } else if (this.state.password !== this.state.passwordConfirm) {
      checkPasswordSame = (
        <Text style={styles.passwordUnmatch}>
          비밀번호를 동일하게 입력해주세요.
        </Text>
      );
    }
    return (
      // <KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={50}>
      <View>
        <ScrollView>
          <KeyboardAvoidingView
            behavior="position"
            keyboardVerticalOffset={-200}
            enabled
          >
            {/* 좌측 상단 종료 버튼(X) */}
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('MyPageScreen')}
            >
              <Image source={require('../imgs/icons/x.png')} style={styles.x} />
            </TouchableOpacity>
            {/* 회원가입 Title */}
            <Text style={styles.title}>가입하고 주문 고고! 🛒</Text>
            {/* 아이디 TextInput */}
            <TextInput
              onChangeText={email => this.setState({ email })}
              placeholder="이메일 : overeats.states@gmail.com"
              style={styles.textInput}
            />
            {/* 비밀번호 TextInput */}
            <TextInput
              secureTextEntry={true}
              onChangeText={password => this.setState({ password: password })}
              placeholder="비밀번호 : 공백 없이 8자 이상"
              style={styles.textInput}
            />
            {/* 비밀번호 확인 TextInput */}
            <TextInput
              secureTextEntry={true}
              onChangeText={text => this.setState({ passwordConfirm: text })}
              placeholder="위에 적은 비밀번호를 똑같이 입력해주세요"
              style={styles.textInput}
            />
            {/* 비밀번호 일치않을 경우 확인요청 텍스트 */}
            <Text style={{ marginLeft: 30 }}>{checkPasswordSame}</Text>
            {/* 이름(username) TextInput */}
            <TextInput
              onChangeText={name => this.setState({ name })}
              placeholder="이름을 입력해주세요"
              style={styles.textInput}
            />
            {/* 전화번호 TextInput */}
            <TextInput
              onChangeText={phoneNumber => {
                this.setState({ phoneNumber: inputDash(phoneNumber) });
              }}
              placeholder="전화번호를 입력해주세요"
              style={styles.textInput}
            />
            {/* 회원가입 신청 버튼 */}
            <View style={styles.signupBtn}>
              <Button
                onPress={() => {
                  this.joinBtn();
                  this.props.navigation.navigate('MyPageScreen');
                }}
                title="버튼 꾸욱! (회원가입)"
              />
            </View>
            <View style={{ height: 60 }} />
          </KeyboardAvoidingView>
        </ScrollView>
      </View>
      // </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  x: {
    marginTop: 50,
    marginLeft: 10,
    width: '10%',
    height: '15%'
  },
  textInput: {
    marginTop: 50,
    marginLeft: 30,
    marginRight: 30,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 30
  },
  signupBtn: {
    marginTop: 20,
    marginBottom: 100,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 15
  },
  passwordMatch: {
    color: 'green',
    marginLeft: 30
  },
  passwordUnmatch: {
    color: 'red',
    marginLeft: 30
  }
});

export default Signup;
