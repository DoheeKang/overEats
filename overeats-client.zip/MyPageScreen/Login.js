import React from 'react';
import {
  View,
  Alert,
  Text,
  TextInput,
  StyleSheet,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  AsyncStorage
} from 'react-native';
import * as LoginAction from '../modules/LoginAction';
import { checkValidEmailAndPasswordLength } from '../modules/checkValidForLogin';
import { createStackNavigator } from 'react-navigation';

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: ''
    };
  }

  render() {
    return (
      <View>
        <KeyboardAvoidingView behavior="position">
          {/* 좌측 상단 종료 버튼(X) */}
          <TouchableOpacity onPress={() => this.props.navigation.goBack(null)}>
            <Image source={require('../imgs/icons/x.png')} style={styles.x} />
          </TouchableOpacity>
          <View style={{ marginTop: 100 }} />
          {/* 아이디 TextInput */}
          <TextInput
            onChangeText={email => this.setState({ email })}
            placeholder="이메일 주소를 입력해주세요"
            style={styles.idOrPassword}
          />
          {/* 비밀번호 TextInput */}
          <TextInput
            secureTextEntry={true}
            onChangeText={password => {
              this.setState({ password });
            }}
            placeholder="비밀번호"
            style={styles.idOrPassword}
          />
          {/* 로그인 버튼 */}
          <TouchableOpacity
            style={styles.btn}
            onPress={async () => {
              const { email, password } = this.state;
              const isValid = checkValidEmailAndPasswordLength({
                email: email,
                password: password
              });
              if (isValid) {
                LoginAction.login(
                  { email: email, password: password },
                  this.props.navigation
                );
              }
            }}
          >
            <Text style={styles.text}>로그인</Text>
          </TouchableOpacity>
          {/* 회원가입으로 넘어가기 */}
          <View style={styles.account}>
            <Text style={{ color: '#adadad' }}>
              혹시, 배달의민족이 처음이신가요?{' '}
              <Text
                style={styles.accountText}
                onPress={() => {
                  this.props.navigation.navigate('TermsAndServices');
                }}
              >
                회원가입
              </Text>
            </Text>
          </View>
          {/* 아이디/비밀번호 찾기 */}
          <View style={styles.account}>
            <Text
              style={styles.accountText}
              onPress={() => Alert.alert('안 찾으면 안될까요? 😰')}
            >
              아이디/비밀번호 찾기
            </Text>
          </View>
        </KeyboardAvoidingView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  x: {
    marginTop: 50,
    marginLeft: 10,
    width: '10%',
    height: '15%'
  },
  idOrPassword: {
    marginTop: 50,
    marginLeft: 30,
    marginRight: 30,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC'
  },
  btn: {
    marginTop: 20,
    marginLeft: 30,
    marginRight: 30,
    alignItems: 'center',
    backgroundColor: '#51CDCA',
    height: 50,
    justifyContent: 'center'
  },
  text: {
    color: 'white',
    fontWeight: 'bold',
    margin: 'auto'
  },
  account: {
    marginTop: 10,
    alignItems: 'center'
  },
  accountText: {
    color: '#adadad',
    textDecorationLine: 'underline'
  }
});

export default Login;
