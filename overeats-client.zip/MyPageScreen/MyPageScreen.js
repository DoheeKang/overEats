import React from 'react';
import {
  Text,
  View,
  Alert,
  Image,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  AsyncStorage
} from 'react-native';
import { createStackNavigator } from 'react-navigation';
import * as Encryption from '../modules/LoginAction';
import DialogInput from 'react-native-dialog-input';
import axios from 'axios';
import Login from './Login';
import * as LoginAction from '../modules/LoginAction';
import TermsAndServices from './TermsAndServices';
import Signup from './Signup';
import { sendToken } from '../modules/sendToken';
import Banner from '../modules/slideBanner';
import IfUserLoggedIn from '../MyPageScreen/IfUserLoggedIn';

class MyPageScreen extends React.Component {
  state = {
    _isLogin: false,
    _password: '',
    isDialogVisible: false
  };

  componentDidMount() {
    this.onLoad();
    this.props.navigation.setParams({ checkIsLogin: this.handleLoginStatus });
  }

  onLoad = () => {
    this.props.navigation.addListener('willFocus', () => {
      this.handleLoginStatus();
    });
  };

  handleLoginStatus = () => {
    AsyncStorage.getItem('isLogin', (err, result) => {
      this.setState({ _isLogin: JSON.parse(result) });
    });
  };

  handleLogout = () => {
    // 로그아웃하는 기능입니다.
    AsyncStorage.setItem('isLogin', JSON.stringify(false));
    Alert.alert('로그아웃되었습니다.', '', [
      {
        text: '확인',
        onPress: () => {
          this.props.navigation.navigate('HomeScreen');
        }
      }
    ]);
  };

  handleSignout = async () => {
    // 회원탈퇴하는 기능입니다.
    let isLogin = await AsyncStorage.getItem('isLogin');
    if (JSON.parse(isLogin)) {
      sendToken('/users/signout/', {}, null, this.props.navigation)
        .then(result => {
          AsyncStorage.setItem('isLogin', JSON.stringify(false));
          this.setState({ _isLogin: false });
          Alert.alert('다음에 또 뵈어요!😭');
          this.props.navigation.navigate('HomeScreen');
        })
        .catch(err => {
          console.log('sendToken으로 회원가입신청했는데 에러다');
          throw err;
        });
    } else {
      console.log('로그인상태 아님');
    }
  };

  // showDialog = value => {
  //   this.setState({ isDialogVisible: value });
  // };

  dialogInput = inputText => {
    if (inputText.trim().length === 0) {
      Alert.alert('비밀번호를 다시 입력해주세요!');
    } else {
      this.showDialog(false);
      this.handleSignout(inputText);
    }
  };

  render() {
    return (
      <ScrollView>
        {/* Swipe Banner */}
        <Banner />
        {/* 로그인/로그아웃 상태에 따라 조건부 렌더링 */}
        <View>
          {/* 회원탈퇴 버튼 눌렀을 때 비밀번호를 받는 textinput popup창 */}
          {/* <DialogInput
            isDialogVisible={this.state.isDialogVisible}
            title={'회원탈퇴 확인창'}
            message={
              '본인확인을 위해 비밀번호를 입력해주세요\n(떠나지 마세요 ㅠㅠ)'
            }
            hintInput={'계정 비밀번호'}
            secureTextEntry={true}
            submitInput={inputText => this.dialogInput(inputText)}
            closeDialog={() => {
              this.showDialog(false);
            }}
          /> */}
          {/* 로그인 상태 값에 따라 [로그인]버튼 또는 [로그아웃+회원탈퇴] 버튼이 노출 */}
          {this.state._isLogin ? (
            <View>
              <IfUserLoggedIn />
              <View>
                <TouchableOpacity
                  style={styles.btn}
                  onPress={this.handleLogout}
                >
                  <Text style={styles.text}>로그아웃</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.btn}
                  onPress={this.handleSignout}
                >
                  <Text style={styles.text}>회원탈퇴</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.btn}
              onPress={() => {
                this.props.navigation.navigate('Login');
              }}
            >
              <Text style={styles.text}>로그인</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  headerTitle: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  btn: {
    backgroundColor: '#51CDCA',
    marginTop: 10,
    marginLeft: 30,
    marginRight: 30,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center'
  },
  text: {
    color: 'white',
    fontWeight: 'bold',
    margin: 'auto',
    alignItems: 'center'
  },
  myInfoContainer: {
    flexDirection: 'column'
  },
  bottomBorderWidth: {
    borderBottomColor: 'grey',
    borderBottomWidth: 1,
    marginVertical: 10,
    marginHorizontal: 20
  },
  myInfoTitle: {
    fontSize: 25,
    color: 'black',
    fontWeight: 'bold',
    marginVertical: 5
  },
  userNameText: {
    marginHorizontal: 20,
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    marginVertical: 5
  },
  userEmailPhoneNumberText: {
    marginHorizontal: 20,
    color: 'black',
    marginVertical: 5
  },
  marketingSwitchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 5
  },
  marketingSwitchText: {
    marginHorizontal: 20,
    color: 'black',
    marginVertical: 5
  }
});

export default createStackNavigator({
  MyPageScreen: {
    screen: MyPageScreen,
    navigationOptions: {
      headerTitle: <Text style={styles.headerTitle}>My 배민</Text>,
      headerLeft: null
    }
  },
  Login: {
    screen: Login,
    navigationOptions: {
      header: null
    }
  },
  TermsAndServices: {
    screen: TermsAndServices,
    navigationOptions: {
      header: null
    }
  },
  Signup: {
    screen: Signup,
    navigationOptions: {
      header: null
    }
  }
});
