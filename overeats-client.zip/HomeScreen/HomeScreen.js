import React, { Component } from 'react';
import {
  Image,
  TouchableOpacity,
  Text,
  View,
  AsyncStorage,
  ScrollView,
  Alert,
  StyleSheet,
  AppState
} from 'react-native';
import RestaurantLists from './RestaurantLists';
import { createStackNavigator } from 'react-navigation';
import Address from './Address';
import Restaurant from './Restaurant';
import Menu from './Menu';
import Cart from './Cart';
import Images from '../imgs/index.js';
import Login from '../MyPageScreen/Login';
import Review from './Review';
import { YellowBox } from 'react-native';
import Banner from '../modules/slideBanner';
import { registerPushToken } from '../modules/pushNotification';
import { Notifications } from 'expo';

YellowBox.ignoreWarnings([
  'Unrecognized WebSocket connection option(s) `agent`, `perMessageDeflate`, `pfx`, `key`, `passphrase`, `cert`, `ca`, `ciphers`, `rejectUnauthorized`. Did you mean to put these under `headers`?'
]);
let categories = [
  { korean: '한식', english: 'korean' },
  { korean: '분식', english: 'snack' },
  { korean: '돈까스/회/일식', english: 'japanese' },
  { korean: '치킨', english: 'chicken' },
  { korean: '피자', english: 'pizza' },
  { korean: '도시락', english: 'lunchbox' },
  { korean: '족발/보쌈', english: 'pork' },
  { korean: '야식', english: 'night' },
  { korean: '중국집', english: 'chinese' },
  { korean: '찜/탕', english: 'soup' },
  { korean: '카페/디저트', english: 'dessert' },
  { korean: '패스트푸드', english: 'junk' },
  { korean: '세계음식', english: 'world' }
];

class HomeScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    // 37th line prevent that 'address' is null
    return {
      headerTitle: (
        <TouchableOpacity
          onPress={() => navigation.navigate('Address')}
          style={styles.headerTitle}
        >
          <Text style={styles.addressText}>
            {navigation.getParam('address')
              ? navigation
                  .getParam('address')
                  .split(' ')
                  .filter(el => el !== '대한민국')
                  .join(' ')
              : ''}
            <Image
              source={require('../imgs/icons/AddressImg.png')}
              style={styles.addressImg}
            />
          </Text>
        </TouchableOpacity>
      )
    };
  };

  //this is changing value of this.props.navigation.params
  // asyncstorage에서 값을 꺼내와야 해서 async가 필요함
  async componentDidMount() {
    if (!(await Notifications.getExpoPushTokenAsync())) {
      registerPushToken;
    }
    // console.log('나는 홈의 didmount');
    const { navigation } = this.props;
    let result = await AsyncStorage.getItem('address');
    navigation.setParams({
      address: result ? result : '주소를 입력하세요.'
    });

    AppState.addEventListener('change', this._handleAppStateChange);
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange);
  }

  _handleAppStateChange(appState = 'active') {
    AsyncStorage.setItem('appState', appState);
  }

  _AddressOnPressHandler = async element => {
    // AsyncStorage.removeItem('address');
    // 주소입력되어있지 않을때 버그 생겨서 주소입력된 경우와 아닌 경우 분기
    let tempAddress = await AsyncStorage.getItem('address');
    tempAddress
      ? this.props.navigation.navigate('RestaurantLists', {
          categoryEnglish: element.english,
          categoryKorean: element.korean
        })
      : Alert.alert('주소를 먼저 입력해주세요.', null, [
          {
            text: '확인',
            onPress: () => this.props.navigation.navigate('Address')
          }
        ]);
  };

  render() {
    return (
      <ScrollView>
        {/* Swipe Banner */}
        <Banner />
        {/* Category */}
        <View style={styles.categoryContainer}>
          {categories.map(el => {
            // categories view create
            return (
              <View style={styles.eachCategory} key={el.korean}>
                <TouchableOpacity
                  style={styles.eachCategoryBtn}
                  onPress={() => this._AddressOnPressHandler(el)}
                >
                  <Image
                    style={styles.eachCategoryImg}
                    source={Images.categories[el.korean]} //category image
                  />
                  <Text style={styles.eachCategoryName}>{el.korean}</Text>
                </TouchableOpacity>
              </View>
            );
          })}
          {/* 빈 영역 (카테고리들을 정돈해서 맞추기 위함) */}
          <View style={styles.emptyCategory}>
            <TouchableOpacity style={styles.eachCategoryBtn}>
              <Image
                style={styles.eachCategoryImg}
                source={require('../imgs/categories/transparent.png')}
              />
              <Text style={styles.eachCategoryName} />
            </TouchableOpacity>
          </View>
          <View style={styles.emptyCategory}>
            <TouchableOpacity style={styles.eachCategoryBtn}>
              <Image
                style={styles.eachCategoryImg}
                source={require('../imgs/categories/transparent.png')}
              />
              <Text style={styles.eachCategoryName} />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  headerTitle: {
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  wrapper: { marginVertical: 20 },
  paginationStyle: {
    backgroundColor: 'rgba(214, 215, 216, 0.2)',
    width: 30,
    borderRadius: 4,
    position: 'absolute',
    bottom: 30,
    right: 20,
    fontSize: 13,
    alignItems: 'center'
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  bannerImg: {
    flex: 1,
    height: undefined,
    width: undefined,
    resizeMode: 'contain'
  },
  addressText: { fontSize: 18, fontWeight: 'bold' },
  addressImg: { width: 20, height: 20 },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center'
  },
  eachCategory: {
    width: 120,
    height: 120,
    borderColor: '#DCDCDC', // bright grey
    borderWidth: 0.5,
    borderStyle: 'dashed'
  },
  eachCategoryBtn: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center'
  },
  eachCategoryImg: { width: '50%', height: '50%' },
  eachCategoryName: { fontSize: 18 },
  emptyCategory: {
    width: 120,
    height: 120
  }
});

// homescreen page, this contain every component in homescreen directory.
export default createStackNavigator({
  HomeScreen,
  Address,
  RestaurantLists,
  Restaurant,
  Menu,
  Address,
  Cart,
  Login: {
    screen: Login,
    navigationOptions: {
      header: null,
      tabBarVisible: false
    }
  },
  Review
});
