import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  AsyncStorage,
  StyleSheet
} from 'react-native';
import { sendToken } from '../modules/sendToken';
import { pushNotification } from '../modules/pushNotification';
import socket from '../modules/socketIoClient';

class Cart extends Component {
  state = { title: 'OverEats', body: '리뷰를 남겨주세요!', token: null };
  // 다시보기: Cart가 나올때마다 클라이언트가 매번 뜨는 거네요? 맨 처음에 여는 게 어떨까요? 미들웨어처럼 어딘가에 따로 빼서 소켓통신과 관련해서는 작업해보는게 좋을 것 같아요.

  _paymentOnPressHandler = async () => {
    const { navigation } = this.props;
    let result = await AsyncStorage.getItem('isLogin');
    result = JSON.parse(result);
    // 로그인이 안되어 있다면 로그인 화면으로 이동
    if (!result) {
      Alert.alert('로그인이 필요합니다.');
      navigation.navigate('Login');
      // 로그인이 되어 있다면 결제를 진행
    } else {
      let orderListResult = await AsyncStorage.getItem('orderList');
      const addressResult = await AsyncStorage.getItem('address');
      sendToken(
        '/restaurants/payment',
        {},
        {
          address: addressResult,
          orderList: JSON.parse(orderListResult),
          _id: navigation.getParam('_id'),
          restaurantName: navigation.getParam('restaurantName')
        },
        this.props.navigation
      ).then(async res => {
        // AsyncStorage.removeItem('order_idArray');
        // 테스트하느라 지우는데 씀
        // orderedList 찾아서 주문한것 찾아와서 집어넣기
        if (res !== 401) {
          this._reviewAlert(res);
          Alert.alert('결제가 완료되었습니다.');
          AsyncStorage.removeItem('orderList');
          navigation.navigate('HomeScreen');
        }
      }); //여기에 평점남기는 알럿을 띄움
    }
  };

  async _reviewAlert(response) {
    const { navigation } = this.props;
    let order_idArray = await AsyncStorage.getItem('order_idArray');
    if (!order_idArray) {
      order_idArray = '[]';
    }
    order_idArray = JSON.parse(order_idArray);
    order_idArray.push(response.data.order_id);
    await AsyncStorage.setItem(
      'order_idArray',
      JSON.stringify(order_idArray) // stringify를 안하면 오류가 생김
    );
    order_idArray.map(el => {
      socket.on(String(el), async data => {
        // AsyncStorage.removeItem('order_idArray');
        // console.log(data);
        AsyncStorage.setItem(
          'order_idArray',
          JSON.stringify(order_idArray.filter(element => element !== el))
        ); // 주문번호 저장 array에서 배달완료된 주문번호를 지움
        let appState = await AsyncStorage.getItem('appState');
        const moveReview = () => {
          Alert.alert('리뷰을 남겨주세요!', null, [
            {
              text: 'OK',
              onPress: () =>
                navigation.navigate('Review', {
                  restaurant_id: data.restaurantKey
                })
            },
            { text: 'Cancel', style: 'cancel' }
          ]);
        };
        if (appState === 'active') {
          moveReview();
        } else if (appState === 'background') {
          // 원래는 else였는데 inactive일때도 반응하는 것 같아서 바꿔봄
          pushNotification();
          moveReview();
        }
      }); //홈스크린에 넣었었지만 주문을 누르는 순간 가장최근 주문번호를 홈스크린은
    }); //알아차리지 못하고 cart는 바로 받기때문에
  }

  render() {
    const { navigation } = this.props;
    const orderList = navigation.getParam('orderList');
    return (
      <View style={styles.cartContainer}>
        <View style={styles.headerLine}>
          <Text style={styles.item}>메뉴</Text>
          <Text style={styles.item}>수량/금액</Text>
          {/* <Text style={styles.item}>금액</Text> */}
        </View>
        {orderList.map((el, index) => {
          const regex = /,/gi;
          let nocomma = el.price.replace(regex, '');
          return (
            <View key={index} style={styles.rowFlexStart}>
              <View style={styles.rowSpaceBetween}>
                <Text style={styles.orderItems}>{el.menu}</Text>
                <Text style={styles.orderItems}>{el.number + ' '}개</Text>
              </View>
              <View style={styles.rowFlexEnd}>
                <Text style={styles.orderItems}>
                  {el.number * Number(nocomma.slice(0, nocomma.length - 1))}원
                </Text>
              </View>
            </View>
          );
        })}
        {/* 장바구니에 넣은 아이템들을 결제하기 */}
        <TouchableOpacity
          style={styles.paymentBtn}
          onPress={this._paymentOnPressHandler}
        >
          <Text style={styles.paymentText}>결제하기</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  cartContainer: { flexDirection: 'column' },
  headerLine: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomColor: 'grey',
    borderBottomWidth: 1,
    marginHorizontal: 20
  },
  item: {
    fontSize: 25,
    marginTop: 15,
    marginLeft: 15
  },
  rowFlexStart: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
    borderBottomColor: '#f0f0f5',
    borderBottomWidth: 1,
    marginHorizontal: 20
  },
  rowSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10
  },
  rowFlexEnd: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginHorizontal: 20
  },
  orderItems: {
    fontSize: 20,
    marginVertical: 5
  },
  paymentBtn: {
    backgroundColor: '#51CDCA',
    marginTop: 25,
    height: 50,
    width: 300,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center'
  },
  paymentText: { fontSize: 25, color: 'white' }
});

export default Cart;
