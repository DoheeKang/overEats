import React, { Component } from 'react';
import {
  TouchableOpacity,
  Text,
  View,
  Image,
  ScrollView,
  AsyncStorage,
  StyleSheet
} from 'react-native';
import axios from 'axios';

class RestaurantLists extends Component {
  state = { data: [], loadingFinish: false };
  static navigationOptions = ({ navigation }) => {
    return {
      headerTitle: (
        <View>
          <Text style={styles.navigationHeader}>
            {navigation.getParam('categoryKorean')}
          </Text>
        </View>
      )
    };
  };
  // encoded = ;
  componentDidMount() {
    AsyncStorage.getItem('address', (err, result) => {
      axios
        .get(
          encodeURI(
            `http://ec2-34-201-173-255.compute-1.amazonaws.com:8080/restaurants/${this.props.navigation.getParam(
              'categoryEnglish'
            )}/${result.split(' ').filter(el => el[el.length - 1] === '구')[0]}`
          )
        )
        .then(res => {
          this.setState({ data: res.data });
          this.setState({ loadingFinish: true });
        });
    });
  }

  _restaurantOnPressHandler = element =>
    this.props.navigation.navigate('Restaurant', {
      menus: element.menus,
      name: element.name,
      rating: element.rating,
      _id: element._id,
      review: element.reviews
    });

  render() {
    // console.log(this.state.data);
    return (
      <ScrollView>
        {!this.state.loadingFinish ? ( //로딩이 끝나지 않았을 때
          <Image
            source={require('../imgs/icons/loading.gif')}
            style={styles.loadingImg}
          />
        ) : this.state.data.length === 0 ? ( // 로딩이 끝나고 음식점이 없을때
          <View style={[styles.arrowContainer, styles.alignCenter]}>
            <Text style={styles.fontSizeEightTeen}>
              음식점이 없습니다.{' '}
              <Image
                style={styles.twentySize}
                source={require('../imgs/icons/mybaemin.png')}
              />
            </Text>
          </View>
        ) : (
          // <Text style={{ fontSize: 40, textAlign: 'center' }}>loading</Text>
          this.state.data.map((
            el // 로딩이 끝나고 음식점이 있을때
          ) => (
            <TouchableOpacity
              key={el._id}
              onPress={() => this._restaurantOnPressHandler(el)}
            >
              {/*restaurant container*/}
              <View style={styles.restaurantView}>
                <Image
                  source={{ uri: el.thumbImg }}
                  style={styles.restaurantImg}
                />
                <View style={styles.textContainer}>
                  <Text style={styles.fontSizeEightTeen}>{el.name}</Text>
                  <Text style={styles.ratingText}>
                    <Image
                      source={require('../imgs/icons/fullStar.png')}
                      style={styles.twentySize}
                    />
                    {el.rating.toFixed(1)}
                  </Text>
                </View>
                {/* arrow container and image*/}
                <View style={styles.arrowContainer}>
                  <Image
                    style={styles.arrowImg}
                    source={require('../imgs/icons/arrow.png')}
                  />
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  navigationHeader: { fontSize: 18, fontWeight: 'bold' },
  restaurantView: {
    width: '100%',
    borderWidth: 0.5,
    borderColor: '#DCDCDC',
    flexDirection: 'row'
  },
  restaurantImg: { height: 100, width: 100 },
  textContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    margin: 15
  },
  fontSizeEightTeen: { fontSize: 18 },
  ratingText: { fontSize: 15 },
  twentySize: { width: 20, height: 20 },
  arrowContainer: { flex: 1, margin: 15, justifyContent: 'center' },
  arrowImg: {
    width: 30,
    height: 45,
    alignSelf: 'flex-end'
  },
  loadingImg: {
    alignSelf: 'center',
    justifyContent: 'center',
    width: 80,
    resizeMode: 'contain'
  },
  alignCenter: {
    alignItems: 'center'
  }
});

export default RestaurantLists;
