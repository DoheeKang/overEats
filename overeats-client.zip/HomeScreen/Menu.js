import React, { Component } from 'react';
import {
  TouchableOpacity,
  Text,
  View,
  Animated,
  StyleSheet,
  AsyncStorage
} from 'react-native';

class Menu extends Component {
  state = {
    number: 1,
    fadeIn: new Animated.Value(0),
    fadeOut: new Animated.Value(1),
    Y: 100
  };

  menu = this.props.navigation.getParam('menu');
  price = this.props.navigation.getParam('price');

  fadeOut() {
    this.state.fadeIn.setValue(1);
    Animated.timing(this.state.fadeIn, {
      toValue: 0,
      duration: 500
    }).start();
  }

  _stateMinusOne = () => this.setState({ number: this.state.number - 1 });

  _statePlusOne = () => {
    this.fadeOut();
    this.setState({ number: this.state.number + 1 });
  };

  _moveToRestaurant = () => this.props.navigation.navigate('Restaurant');

  _cartIn = () => {
    AsyncStorage.getItem('orderList', async (err, result) => {
      if (result !== null && result[0] === '[') result = JSON.parse(result);
      else result = [];
      if (this.menu) {
        result.push({
          menu: this.menu,
          number: this.state.number,
          price: this.price
        });
        await AsyncStorage.setItem('orderList', JSON.stringify(result));
      }
    });
  };

  render() {
    const { navigation } = this.props;
    const menu = navigation.getParam('menu');
    return (
      <View style={styles.container}>
        <Text style={styles.menuText}>{menu}</Text>
        <Animated.View
          style={{
            opacity: this.state.fadeIn
          }}
        >
          <View style={styles.animationContainer}>
            <Text style={styles.animationText}>+1</Text>
          </View>
        </Animated.View>

        <View style={styles.flexRow}>
          <TouchableOpacity
            onPress={this._stateMinusOne}
            style={{ marginRight: 40 }}
          >
            <Text style={styles.fontSizeThirty}>-</Text>
          </TouchableOpacity>

          <Text style={styles.fontSizeThirty}>
            {this.state.number.toString()}
          </Text>
          <TouchableOpacity
            onPress={this._statePlusOne}
            style={{ marginLeft: 40 }}
          >
            <Text style={styles.fontSizeThirty}>+</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={{ marginTop: 30 }}
          onPress={() => {
            this._cartIn();
            this._moveToRestaurant();
          }}
        >
          <Text>장바구니에 담기</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center' },
  menuText: { fontSize: 35, marginTop: 50 },
  animationContainer: { marginTop: 30, width: 50 },
  animationText: { fontSize: 15, textAlign: 'center' },
  flexRow: { flexDirection: 'row' },
  fontSizeThirty: { fontSize: 30 }
});
export default Menu;
