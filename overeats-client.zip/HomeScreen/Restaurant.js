import React, { Component } from 'react';
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  Image,
  AsyncStorage,
  StyleSheet
} from 'react-native';
import Stars from 'react-native-stars';

class Restaurant extends Component {
  state = { tab: 'menu' };

  _navigateMenu = element =>
    this.props.navigation.navigate('Menu', {
      menu: element.name,
      price: element.price
    });

  _getOrderlistAndMoveToCart = () => {
    AsyncStorage.getItem('orderList', (err, result) => {
      if (result !== null) {
        this.props.navigation.navigate('Cart', {
          orderList: JSON.parse(result),
          _id: this.props.navigation.getParam('_id'),
          restaurantName: this.props.navigation.getParam('name')
        });
      }
    });
  };
  render() {
    const { navigation } = this.props;
    const menu = navigation.getParam('menu');
    const number = navigation.getParam('number');
    const price = navigation.getParam('price');
    //render 할때마다 불려야할까요?

    return (
      <View>
        <ScrollView style={{ height: '100%' }}>
          <View style={styles.headerContainer}>
            <Text style={styles.titleText}>{navigation.getParam('name')}</Text>
            <View style={[styles.ratingContainer, styles.rowAndCenter]}>
              <Stars
                half={true}
                display={Number(navigation.getParam('rating').toFixed(2))}
                spacing={4}
                starSize={20}
                count={5}
                fullStar={require('../imgs/icons/fullStar.png')}
                emptyStar={require('../imgs/icons/emptyStar.png')}
                halfStar={require('../imgs/icons/halfStar.png')}
              />
              <Text style={styles.ratingText}>
                {navigation.getParam('rating').toFixed(1)}
              </Text>
            </View>
          </View>
          <View style={styles.rowAndCenter}>
            <TouchableOpacity
              style={[
                styles.tab,
                { borderWidth: this.state.tab === 'menu' ? 0.5 : 0 }
              ]}
              onPress={() => this.setState({ tab: 'menu' })}
            >
              <Text style={styles.tabText}>메뉴</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.tab,
                {
                  borderWidth: this.state.tab === 'menu' ? 0 : 0.5
                }
              ]}
              onPress={() => this.setState({ tab: 'review' })}
            >
              <Text style={styles.tabText}>리뷰</Text>
            </TouchableOpacity>
          </View>
          {this.state.tab === 'menu' ? (
            // Here Menu Tab
            <View>
              {navigation.getParam('menus').map(el => (
                <TouchableOpacity
                  key={el.name}
                  onPress={() => this._navigateMenu(el)}
                >
                  <View style={styles.menus}>
                    <Text style={styles.menuName}>{el.name}</Text>
                    <Text style={styles.menuPrice}>{el.price}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            // Here Review Tab
            <View>
              {navigation.getParam('review').length ? ( // reviews exist
                navigation.getParam('review').map((el, index) => {
                  if (el.content) {
                    //내용이 있는 애들만 출력
                    return (
                      <View style={styles.reviews} key={index}>
                        <View style={styles.usernameContainer}>
                          <Text style={styles.usernameText}>{el.name}</Text>
                        </View>
                        <View style={styles.reviewRating}>
                          <Stars
                            half={true}
                            display={el.rating}
                            spacing={4}
                            starSize={13}
                            count={5}
                            fullStar={require('../imgs/icons/fullStar.png')}
                            emptyStar={require('../imgs/icons/emptyStar.png')}
                            halfStar={require('../imgs/icons/halfStar.png')}
                          />
                        </View>
                        <View style={{ flex: 2 }}>
                          <Text style={styles.contentText}>{el.content}</Text>
                        </View>
                      </View>
                    );
                  }
                })
              ) : (
                // review not exist
                <View style={styles.noReviewContainer}>
                  <Text style={{ fontSize: 15 }}>아직 리뷰가 없습니다.</Text>
                </View>
              )}
            </View>
          )}
        </ScrollView>
        <View style={styles.cartImgContainer}>
          {/* 다시보기: orderlist를 여러번 받네요? */}
          <TouchableOpacity
            onPress={this._getOrderlistAndMoveToCart}
            style={styles.cartImg}
            //위의 스타일을 지정해 주지 않으면 img의 크기가 더 커서 안눌리는 부분이 있음
          >
            <Image
              source={{
                uri:
                  'https://cdn0.iconfinder.com/data/icons/webshop-essentials/100/shopping-cart-512.png'
              }}
              style={styles.cartImg}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  headerContainer: {
    height: 90,
    justifyContent: 'center',
    flexDirection: 'column'
  },
  titleText: { fontSize: 28, textAlign: 'center' },
  ratingContainer: {
    marginTop: 10
  },
  rowAndCenter: { flexDirection: 'row', justifyContent: 'center' },
  ratingText: { fontSize: 18, marginLeft: 8 },
  tab: {
    width: '50%',
    marginTop: 8,
    alignItems: 'center',
    borderColor: '#DCDCDC',
    borderBottomWidth: 0
  },
  tabText: { marginTop: 3, fontSize: 25 },
  menus: {
    width: '100%',
    borderWidth: 0.5,
    borderColor: '#DCDCDC',
    flexDirection: 'column',
    height: 80,
    justifyContent: 'center'
  },
  menuName: {
    fontWeight: 'bold',
    marginLeft: 22,
    fontSize: 18
  },
  menuPrice: { marginLeft: 22, fontSize: 15, marginTop: 5 },
  reviews: {
    width: '100%',
    borderWidth: 0.5,
    borderColor: '#DCDCDC',
    flexDirection: 'column',
    height: 120,
    justifyContent: 'center',
    flex: 1
  },
  usernameContainer: { flex: 1, marginTop: 10 },
  usernameText: {
    fontWeight: 'bold',
    marginLeft: 22,
    fontSize: 17
  },
  reviewRating: {
    marginLeft: 22,
    flexDirection: 'row',
    flex: 1
  },
  contentText: {
    marginLeft: 22,
    fontSize: 17,
    marginTop: 5
  },
  noReviewContainer: {
    alignItems: 'center',
    marginTop: 20
  },
  cartImgContainer: {
    position: 'absolute',
    top: '85%',
    left: '75%',
    right: 0,
    bottom: 0,
    width: 20,
    height: 20
  },
  cartImg: { width: 70, height: 70 }
});

export default Restaurant;
