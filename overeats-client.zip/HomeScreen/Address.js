import React, { Component } from 'react';
import {
  Alert,
  TouchableOpacity,
  View,
  Text,
  AsyncStorage,
  StyleSheet
} from 'react-native';
import GooglePlacesInput from './GooglePlacesInput';

class Address extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: 'sample text'
    };
  }

  _submitAddress = async () => {
    AsyncStorage.setItem('address', this.state.text);
    let storageAddress = await AsyncStorage.getItem('address');
    Alert.alert('입력이 완료되었습니다.', null, [
      {
        text: 'OK',
        onPress: () =>
          this.props.navigation.navigate('HomeScreen', {
            address: storageAddress
          })
      }
    ]);
  };

  render() {
    return (
      <View>
        <View />
        <Text style={styles.explainText}>지번, 도로명을 입력하세요</Text>
        <View style={{ flexDirection: 'row' }}>
          <GooglePlacesInput
            style={{ backgroundColor: 'red' }}
            onPress={x => this.setState({ text: x })}
          />
          <TouchableOpacity
            style={styles.inputBtn}
            onPress={this._submitAddress}
          >
            <Text>입력</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  explainText: { fontSize: 33, margin: 13 },
  inputBtn: {
    height: 40,
    borderColor: '#DCDCDC',
    borderWidth: 1,
    width: 50,
    marginRight: 20,
    alignItems: 'center',
    justifyContent: 'center'
  }
});

export default Address;
