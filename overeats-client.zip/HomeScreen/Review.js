import React, { Component } from 'react';
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  StyleSheet
} from 'react-native';
import Stars from 'react-native-stars';
import { sendToken } from '../modules/sendToken';

class Review extends Component {
  state = {
    rating: 2.5,
    review: null
  };
  render() {
    const { navigation } = this.props;
    const restaurant_id = navigation.getParam('restaurant_id');
    return (
      <View style={styles.container}>
        <View style={styles.marginThirty}>
          <Stars
            style={styles.marginThirty}
            half={true}
            default={2.5}
            update={val => {
              this.setState({ rating: val });
            }}
            spacing={4}
            starSize={40}
            count={5}
            fullStar={require('../imgs/icons/fullStar.png')}
            emptyStar={require('../imgs/icons/emptyStar.png')}
            halfStar={require('../imgs/icons/halfStar.png')}
          />
        </View>
        <View style={styles.inputText}>
          <TextInput
            // ref={el => console.log('나는', el)}
            style={styles.input}
            placeholder="리뷰를 남겨주세요."
            onChangeText={text => this.setState({ review: text })}
          />
        </View>
        <View style={styles.marginThirty}>
          <TouchableOpacity
            style={{ justifyContent: 'center' }}
            onPress={() => {
              Alert.alert('리뷰가 등록되었습니다.');
              navigation.navigate('HomeScreen');
              sendToken(
                '/restaurants/review',
                {},
                {
                  restaurantKey: restaurant_id,
                  rating: this.state.rating,
                  content: this.state.review
                },
                this.props.navigation
              );
            }}
          >
            <Text style={styles.fontSize25}>등록</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'column',
    alignItems: 'center'
  },
  marginThirty: { marginTop: 30 },
  inputText: {
    marginTop: 30,
    width: '70%',
    height: 130,
    borderColor: '#DCDCDC',
    borderWidth: 0.5
  },
  input: { width: '100%', height: '100%', flexWrap: 'wrap' }
});

export default Review;
