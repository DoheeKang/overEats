import React from 'react';
import {
  Text,
  View,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  AsyncStorage,
  RefreshControl
} from 'react-native';
import { createStackNavigator } from 'react-navigation';
import OrderList from '../OrderListsScreen/orderList';
import * as Convert from '../modules/convertPrice';
import { sendToken } from '../modules/sendToken';
import axios from 'axios';

class OrderListsScreen extends React.Component {
  state = {
    goRefresh: false,
    data: [],
    isLoadData: false,
    isLogin: false
  };

  static navigationOptions = ({ navigation }) => {
    return {
      headerRight: (
        <TouchableOpacity
          style={styles.refreshBtn}
          onPress={navigation.getParam('handleGoRefresh')}
        >
          <Image
            source={require('../imgs/icons/refreshBtn.png')}
            style={styles.refreshImg}
          />
        </TouchableOpacity>
      )
    };
  };

  componentDidMount() {
    this.onLoad();
    this.props.navigation.setParams({
      handleGoRefresh: this.getUserOrderLists
    });
    this.getUserOrderLists();
  }

  onLoad = () => {
    this.props.navigation.addListener('willFocus', () => {
      this.getUserOrderLists();
    });
  };

  getUserOrderLists = async () => {
    let isLogin = await AsyncStorage.getItem('isLogin');
    if (JSON.parse(isLogin)) {
      sendToken('/users/info/', {}, null, this.props.navigation)
        .then(result => {
          let { ordered } = result.data;
          this.setState({ data: ordered, isLoadData: true });
          console.log('data :', this.state.data);
        })
        .catch(err => {
          console.log('sendToken했는데 에러다');
          throw err;
        });
    }
  };

  handleLoginStatus = () => {
    AsyncStorage.getItem('isLogin', (err, result) => {
      this.setState({ isLogin: JSON.parse(result) });
    });
  };

  render() {
    return (
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={this.state.goRefresh}
            onRefresh={this._onRefresh}
          />
        }
      >
        <View style={styles.container}>
          {this.state.isLogin && !this.state.isLoadData ? (
            <Image
              source={require('../imgs/icons/loading.gif')}
              style={styles.loadingImg}
            />
          ) : this.state.data.length === 0 ? (
            <View style={styles.noOrderHistoryContainer}>
              <Text style={styles.noOrderHistoryMsg}>
                아직 주문내역이 없으시네요!{'\n'}지금 바로 주문해보세요!🍔
              </Text>
            </View>
          ) : (
            <OrderList data={this.state.data} />
          )}
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  headerTitle: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  noOrderHistoryContainer: {
    flex: 1,
    marginTop: 50,
    flexDirection: 'column',
    alignItems: 'center'
  },
  noOrderHistoryMsg: {
    textAlign: 'center',
    fontSize: 20
  },
  refreshBtn: {
    flexDirection: 'row',
    justifyContent: 'flex-end'
  },
  refreshImg: {
    maxWidth: 40,
    height: 40,
    marginRight: 10,
    resizeMode: 'contain'
  },
  loadingImg: {
    alignSelf: 'center',
    justifyContent: 'center',
    width: 80,
    resizeMode: 'contain'
  }
});

export default createStackNavigator({
  OrderListsScreen: {
    screen: OrderListsScreen,
    navigationOptions: {
      headerTitle: <Text style={styles.headerTitle}>주문내역</Text>
    }
  }
});
