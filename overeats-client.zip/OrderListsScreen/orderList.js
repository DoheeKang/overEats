import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default class OrderList extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { data } = this.props;
    return (
      <View style={styles.orderhistoryContainer}>
        {data.map((el, index) => {
          return (
            <View key={'orderlists' + index} style={styles.borderLine}>
              <Text style={styles.orderhistoryResName}>
                {el.restaurantName}
              </Text>
              {el.orderList.map((order, innerindex) => {
                return (
                  <View key={'list' + innerindex}>
                    <Text style={styles.orderhistoryMenus}>{order.menu}</Text>
                    <Text style={styles.orderhistoryMenus}>{order.price}</Text>
                  </View>
                );
              })}
              <TouchableOpacity style={styles.reOrderBtn}>
                <Text style={styles.btnText}>다시 주문하기</Text>
              </TouchableOpacity>
            </View>
          );
        })}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  orderhistoryContainer: {
    flexDirection: 'column',
    margin: 10
  },
  orderhistoryResName: {
    fontWeight: 'bold',
    fontSize: 15,
    marginTop: 30,
    marginHorizontal: 20
  },
  orderhistoryMenus: {
    color: 'grey',
    marginVertical: 5,
    marginHorizontal: 20
  },
  reOrderBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    marginLeft: 20,
    marginRight: 20,
    marginBottom: 10,
    height: 40,
    borderWidth: 1,
    borderColor: 'grey'
  },
  borderLine: {
    borderBottomColor: '#f0f0f5',
    borderBottomLeftRadius: 1,
    borderBottomRightRadius: 1,
    borderBottomWidth: 1
  }
});

// {this.state.data.map((el, index) => {
//   let orderCase = null;
//   const orderListsLength = el.orderList.length;
//   if (orderListsLength <= 1) {
//     orderCase = (
//       <View>
//         <Text style={styles.orderhistoryMenus}>
//           {el.orderList.menu + ' '}+{el.orderList.number + '개'}
//         </Text>
//         <Text style={styles.orderhistoryMenus}>
//           {el.orderList.price}
//         </Text>
//       </View>
//     );
//   } else {
//     let totalPrice = el.orderList.map(list => {
//       let priceToNumber = Convert.converToNumber(list.price);
//       return Convert.converToStringPrice(priceToNumber);
//     });
//     orderCase = (
//       <View>
//         <Text style={styles.orderhistoryMenus}>
//           {el.orderList[0].menu + ' '}+
//           {el.orderList[0].number + '개 외 '}+{orderListsLength - 1}
//         </Text>
//         <Text style={styles.orderhistoryMenus}>
//           {totalPrice + ' 원'}
//         </Text>
//       </View>
//     );
//   }
//   return (
//     <View key={'orderlists' + index}>
//       {/* 식당이름, 메뉴, 금액 표시되는 곳*/}
//       <View style={styles.orderhistoryContainer}>
//         <Text style={styles.orderhistoryResName}>
//           {el.restaurantName}
//         </Text>
//         {orderCase}
//       </View>
//       {/* 다시 주문하기 버튼 */}

//     </View>
//   );
// })}
