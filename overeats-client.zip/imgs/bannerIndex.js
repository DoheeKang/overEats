// const BannerImages = {
//   0: require('./banners/wannadrinkbeer.png'),
//   1: require('./banners/overeats.png'),
//   2: require('./banners/codestatesbanner.png'),
//   3: require('./banners/whereismycup.png'),
//   4: require('./banners/hoahoa.png'),
//   5: require('./banners/vegetas.png'),
//   6: '짜잔!'
// };

// const BannerImages = {
//   uri: [
//     'wannadrinkbeer.png',
//     'overeats.png',
//     'codestatesbanner.png',
//     'whereismycup.png',
//     'hoahoa.png',
//     'vegetas.png'
//   ]
// };

const BannerImages = {
  uri: [
    require('./banners/wannadrinkbeer.png'),
    require('./banners/overeats.png'),
    require('./banners/codestatesbanner.png'),
    require('./banners/whereismycup.png'),
    require('./banners/hoahoa.png'),
    require('./banners/vegetas.png')
  ]
};

// { uri: require('./banners/wannadrinkbeer.png') },
// { uri: require('./banners/overeats.png') },
// { uri: require('./banners/codestatesbanner.png') },
// { uri: require('./banners/whereismycup.png') },
// { uri: require('./banners/hoahoa.png') },
// { uri: require('./banners/vegetas.png') }

export default BannerImages;
