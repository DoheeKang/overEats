const images = {
  categories: {
    도시락: require('./categories/lunchbox.png'),
    분식: require('./categories/snack.png'),
    '족발/보쌈': require('./categories/pork.png'),
    중국집: require('./categories/chinese.png'),
    '찜/탕': require('./categories/soup.png'),
    치킨: require('./categories/chicken.png'),
    패스트푸드: require('./categories/junk.png'),
    피자: require('./categories/pizza.png'),
    한식: require('./categories/korean.png'),
    '돈까스/회/일식': require('./categories/japanese.png'),
    야식: require('./categories/night.png'),
    '카페/디저트': require('./categories/dessert.png'),
    세계음식: require('./categories/world.png')
  }
};

export default images;
