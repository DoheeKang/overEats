export const checkValidEmailAndPasswordLength = data => {
  // email과 password의 모든 공백을 제거한 상태로 검사할 것
  const email = data.email.replace(/ /gi, '');
  const password = data.password.replace(/ /gi, '');
  // email에는 '@'와 1개 이상의 '.'이 포함되어 있을 것
  // password는 공백 불포함 8자 이상일 것
  const isEmailIncludesAtAndDot = email.includes('@') && email.includes('.');
  const isLengthOfPasswordMoreThanEight = !!(password.length >= 8);
  // return 'true' or 'false'
  return isEmailIncludesAtAndDot && isLengthOfPasswordMoreThanEight;
};
