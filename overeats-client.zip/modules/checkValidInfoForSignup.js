export const checkValidInfo = data => {
  // email,password,name,phoneNumber의 모든 공백을 제거한 상태로 검사할 것
  let email = data.email.replace(/ /gi, '');
  let password = data.password.replace(/ /gi, '');
  let name = data.name.replace(/ /gi, '');
  let phoneNumber = data.phoneNumber.replace(/ /gi, '').replace(/-/gi, '');
  // email에는 '@'와 1개 이상의 '.'이 포함되어 있을 것
  // password는 공백 불포함 8자 이상일 것
  // name 길이는 0보다 클 것
  // phoneNumber 길이는 10자리 또는 11자리일 것
  let isEmailIncludesAtAndDot = email.includes('@') && email.includes('.');
  let isLengthOfPasswordMoreThanEight = !!(password.length >= 8);
  let isLengthOfNameMoreThanZero = !!(name.length > 0);
  let isLengthOfPhoneNumberTenOrEleven = !!(
    (Number(phoneNumber) && phoneNumber.length === 10) ||
    (Number(phoneNumber) && phoneNumber.length === 11)
  );
  // return 'true' or 'false'

  if (!isEmailIncludesAtAndDot) {
    console.log('이메일 오류', email);
  }

  if (!isLengthOfPasswordMoreThanEight) {
    console.log('비밀번호오류', password);
  }

  if (!isLengthOfNameMoreThanZero) {
    console.log('이름 오류', name);
  }

  if (!isLengthOfPhoneNumberTenOrEleven) {
    console.log('전화번호오류', phoneNumber);
  }
  return (
    isEmailIncludesAtAndDot &&
    isLengthOfPasswordMoreThanEight &&
    isLengthOfNameMoreThanZero &&
    isLengthOfPhoneNumberTenOrEleven
  );
};
