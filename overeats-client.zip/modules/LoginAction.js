import axios from 'axios';
import { Alert, AsyncStorage } from 'react-native';
import alphabetStorage from './alphabetStorage';

export const postLoginAPI = data => {
  const headers = { 'Content-Type': 'application/json' };
  return axios.post(
    'http://54.180.102.251:8080/users/signin',
    data,
    { headers: headers }
  );
};

export const simpleEncryption = str => {
  return alphabetStorage.o + str + alphabetStorage.v;
};

export const simpleDecryption = str => {
  let cutFront = str.slice(22);
  return cutFront.replace(alphabetStorage.v, '');
};

export const login = (data, propsNavigtion, screenName) => {
  return postLoginAPI(data)
    .then(res => {
      AsyncStorage.setItem('accessToken', res.headers['access-token']);
      AsyncStorage.getItem('accessToken', (e, r) => console.log(r));
      Expo.SecureStore.setItemAsync(
        'refreshToken',
        res.headers['refresh-token']
      );
      // console.log(
      //   'refreshToken',
      //   await Expo.SecureStore.getItemAsync('refreshToken')
      // );
      // AsyncStorage.setItem('_email', simpleEncryption(data.email));
      AsyncStorage.setItem('isLogin', JSON.stringify(true));
      Alert.alert('어서오세요!\n이제 맛있는 걸 먹으러 가볼까요?', '🍖🌭🍡🍱', [
        {
          text: '그럽시다!',
          onPress: () => {
            propsNavigtion.goBack();
          }
        }
      ]);
    })
    .catch(error => {
      AsyncStorage.setItem('isLogin', JSON.stringify(false));
      console.log('error', error);
      Alert.alert(
        '로그인에 실패했습니다.','아이디 또는 비밀번호를 다시 확인해주세요.'
      );
    });
};
