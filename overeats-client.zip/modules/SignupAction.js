import axios from 'axios';
import { Alert, AsyncStorage } from 'react-native';

function postSignupAPI(data) {
  return axios.post(
    'http://54.180.102.251:8080/users/signup',
    data
  );
}

export const signup = (data, propsNavigation) => {
  console.log('singup 요청 진행 중....');
  console.log('회원가입 요청 데이터: \n', data);
  return postSignupAPI(data)
    .then(result => {
      console.log('sign-up successfully :\n', JSON.stringify(result));
      Alert.alert('오예!', '환영합니다!\n회원가입이 완료되었습니다.', [
        {
          text: '오예!',
          onPress: () => {
            AsyncStorage.setItem('isLogin', JSON.stringify(false));
            propsNavigation.navigate('MyPageScreen');
          }
        }
      ]);
    })
    .catch(error => {
      console.log('sign-up failed:\n', error);
    });
};
