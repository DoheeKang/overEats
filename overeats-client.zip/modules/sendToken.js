import { AsyncStorage, Alert } from 'react-native';
import axios from 'axios';

export const sendToken = async (route, headers, data, propsNavigation) => {
  const requestAxios = token => {
    if (data) {
      console.log('post가 실행되었습니다.');
      return axios.post(
        'http://54.180.102.251:8080' + route,
        data,
        {
          headers: Object.assign(
            {
              'x-access-token': token
            },
            headers
          )
        }
      );
    } else {
      console.log('get이 실행되었습니다.');
      return axios.get(
        'http://54.180.102.251:8080' + route,
        {
          headers: {
            'x-access-token': token
          }
        }
      );
    }
  };
  let accessToken = await AsyncStorage.getItem('accessToken');
  return requestAxios(accessToken)
    .then(res => res)
    .catch(async err => {
      // console.log('여기는 access걸림');
      // console.log(err);
      let refreshToken = await Expo.SecureStore.getItemAsync('refreshToken');
      return requestAxios(refreshToken)
        .then(async res => {
          // console.log('access토큰 res.headers', res.headers);
          // console.log('access토큰 res.body', res.body);
          // console.log('access토큰 res.headers', res.headers['access-token']);
          await AsyncStorage.setItem(
            'accessToken',
            res.headers['access-token']
          );
          return requestAxios(res.headers['access-token']).then(
            response => response
          );
          // .catch(errorrrr => console.log('잡았다 요놈!'));
        })
        .catch(async error => {
          Alert.alert(
            '아이쿠! 😨',
            '오랜만에 OverEats를 이용해주시는군요!\n불편하시겠지만 보안을 위해\n다시 한번 로그인을 부탁드려요!',
            [
              {
                text: '오케이!',
                onPress: async () => {
                  await AsyncStorage.setItem('isLogin', JSON.stringify(false));
                  propsNavigation.navigate('MyPageScreen');
                }
              }
            ]
          );

          return error.response.status;
        });
    });
};
