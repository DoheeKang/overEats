import React, { Component } from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';
import Swiper from 'react-native-swiper';
import BannerImages from '../imgs/bannerIndex';

export default class Banner extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bannerIndex: 0
    };
  }

  renderPagination = (index, total, context) => {
    return (
      <View style={styles.paginationStyle}>
        <Text style={{ color: 'white' }}>
          <Text>{index + 1}</Text>/{total}
        </Text>
      </View>
    );
  };

  render() {
    return (
      <View>
        <Swiper
          style={styles.wrapper}
          height={200}
          onMomentumScrollEnd={(e, state, context) =>
            this.setState({ bannerIndex: state.index })
          }
          renderPagination={this.renderPagination}
          autoplayDirection={true}
          autoplayTimeout={2.5}
          autoplay
        >
          {BannerImages.uri.map((el, index) => {
            return (
              <View style={styles.slide} key={'imgKey' + index}>
                <Image
                  style={styles.bannerImg}
                  source={BannerImages.uri[index]}
                />
              </View>
            );
          })}
        </Swiper>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: 20, height: '20%' },
  paginationStyle: {
    backgroundColor: 'rgba(214, 215, 216, 0.2)',
    width: 30,
    borderRadius: 4,
    position: 'absolute',
    bottom: 30,
    right: 20,
    fontSize: 13,
    alignItems: 'center'
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  bannerImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain'
  }
});
