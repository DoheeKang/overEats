import { Permissions, Notifications } from 'expo';

const PUSH_ENDPOINT = 'https://exp.host/--/api/v2/push/send';
export async function registerPushToken() {
  const { status: existingStatus } = await Permissions.getAsync(
    Permissions.NOTIFICATIONS
  );
  let finalStatus = existingStatus;
  if (existingStatus !== 'granted') {
    const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
    finalStatus = status;
  }
  if (finalStatus !== 'granted') {
    return;
  }
}

export async function pushNotification() {
  let token = await Notifications.getExpoPushTokenAsync();
  console.log(token);
  return fetch(PUSH_ENDPOINT, {
    body: JSON.stringify({
      to: token,
      title: 'OverEats',
      body: '리뷰를 남겨주세요!'
      // data: { message: `${'OverEats'} - ${'리뷰를 남겨주세요!'}` }
    }),
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json'
    },
    method: 'POST'
  });
}
