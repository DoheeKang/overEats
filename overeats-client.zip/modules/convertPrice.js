export const converToNumber = value => {
  return Number(
    value
      .split('')
      .filter(str => {
        return str !== ',' && str !== '원';
      })
      .join('')
  );
};

export const converToStringPrice = value => {
  let convertToStringInArr = value.toString().split('');
  let turn = 0;
  for (let i = 1; i < convertToStringInArr.length / 3; i += 1) {
    if (i === 1) {
      convertToStringInArr.splice(-3, 0, ',');
      turn += 1;
    } else {
      convertToStringInArr.splice(-3 * i - turn, 0, ',');
      turn += 1;
    }
  }
  return convertToStringInArr.join('');
};
