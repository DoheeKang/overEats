const alphabetStorage = {
  o: '@81989@f!yingsquirrel*',
  v: '@221989@f!yingsquirrel*'
};

export default alphabetStorage;
