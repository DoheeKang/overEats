import React, { Component } from 'react';
import { Text, View, Image } from 'react-native';
import { createBottomTabNavigator, createAppContainer } from 'react-navigation';
import HomeScreen from './HomeScreen/HomeScreen.js';
// import Address from './Address';
// import RestaurantLists from './RestaurantLists';
import MyPageScreen from './MyPageScreen/MyPageScreen';
import OrderListsScreen from './OrderListsScreen/OrderListsScreen';

/* OderListsScreen 은 OrderListsScreen.js 파일로 따로 분류해서 작업하기 때문에 주석처리하였습니다.
class OrderListsScreen extends Component {
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>OrderLists!</Text>
      </View>
    );
  }
}
*/

/* MyPageScreen 은 MyPageScreen.js 파일로 따로 분류해서 작업하기 때문에 주석처리하였습니다.
class MyPageScreen extends Component {
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>MyPage!</Text>
      </View>
    );
  }
}
*/

const TabNavigator = createBottomTabNavigator({
  홈: {
    screen: HomeScreen,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => (
        <Image
          source={require('./imgs/icons/home.png')}
          style={{ width: 25, height: 25 }}
        />
      )
    }
  },
  주문내역: {
    screen: OrderListsScreen,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => (
        <Image
          source={require('./imgs/icons/orderlist.png')}
          style={{ width: 25, height: 25 }}
        />
      )
    }
  },
  my배민: {
    screen: MyPageScreen,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => (
        <Image
          source={require('./imgs/icons/mybaemin.png')}
          style={{ width: 25, height: 25 }}
        />
      )
    }
  }
});

export default createAppContainer(TabNavigator);
