exports.menuSchema = {
  name: String,
  price: String
};
