const category = {
  korean: '한식',
  snack: '분식',
  japanese: '돈까스,회,일식',
  chicken: '치킨',
  pizza: '피자',
  lunchbox: '도시락',
  pork: '족발,보쌈',
  night: '야식',
  chinese: '중국집',
  soup: '찜,탕',
  dessert: '카페,디저트',
  junk: '패스트푸드',
  world: '세계음식'
};

module.exports = category;
