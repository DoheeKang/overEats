# OverEats

<br>

## 기본 환경 설치

- node@latest

<br>

## Package Dependencies

- [express](https://www.npmjs.com/package/express)
- [bcrypt](https://www.npmjs.com/package/bcrypt)
- [mongoose](https://www.npmjs.com/package/mongoose)
- [jsonwebtoken](https://www.npmjs.com/package/jsonwebtoken)
- [socket.io](https://www.npmjs.com/package/socket.io)
- [jest](https://www.npmjs.com/package/jest)

<br>

## `notion`

[기획문서](https://www.notion.so/73c2cb64c85743c990bbf60e5b7b147d)

## `service site`

[서비스 실행 사이트](https://play.google.com/store/apps/details?id=com.overeats.states)
