module.exports = {
  secret: 'COdEStATeS-OvEReATs',
  mongodbUri: 'mongodb://13.125.252.142:38380/overEats'
};
